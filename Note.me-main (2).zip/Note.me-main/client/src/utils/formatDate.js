export const formatDate = (date)=>{
    const d = new Date();
    return d.toDateString;
}