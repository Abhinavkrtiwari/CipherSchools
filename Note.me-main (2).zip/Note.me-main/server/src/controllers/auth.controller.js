const user = require("../models/userModel");

async function getMe(req, res) {}

// async function login(req, res) {}

module.exports = {
  getMe
};
